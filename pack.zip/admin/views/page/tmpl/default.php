<?php
/**
 * Created by PhpStorm.
 * User: sau
 * Date: 22.03.18
 * Time: 16:14
 */

?>
<div class="span6">
	<?php
	echo '<pre>';
	print_r($this->item);
	echo '</pre>';
	?>
</div>
<div class="span6">
	<?php
	echo '<pre>';
	print_r($this->form);
	echo '</pre>';
	?>
</div>

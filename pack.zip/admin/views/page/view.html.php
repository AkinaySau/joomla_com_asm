<?php

use Sau\Joomla\ASM\Abs\SAdminHtmlView;

/**
 * Created by PhpStorm.
 * User: sau
 * Date: 22.03.18
 * Time: 12:49
 * @since 1.0
 */
class ASMViewPage extends SAdminHtmlView {

	/**
	 * Displays a toolbar for a specific page.
	 *
	 * @return  void.
	 *
	 * @since   1.0
	 */
	protected function toolbar () {
		// TODO: Implement toolbar() method.
	}

	/**
	 * Set title
	 *
	 * @return string
	 *
	 * @since version
	 */
	protected function setTitle (): string {
		// TODO: Implement setTitle() method.
	}
}
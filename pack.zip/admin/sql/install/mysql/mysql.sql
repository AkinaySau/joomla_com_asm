IF NOT EXISTS(#__asm_pages)
  CREATE TABLE
    #__asm_pages;


<?php
/**
 * Created by PhpStorm.
 * User: sau
 * Date: 21.03.18
 * Time: 14:41
 */

use \Joomla\CMS\MVC\Controller\FormController;

class ASMControllerPage extends FormController {
}
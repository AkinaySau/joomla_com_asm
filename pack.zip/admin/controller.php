<?php
/**
 * Created by PhpStorm.
 * User: sau
 * Date: 21.03.18
 * Time: 11:09
 */

use \Joomla\CMS\MVC\Controller\AdminController;

class ASMController extends AdminController {

}
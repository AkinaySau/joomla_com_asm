<?php
/**
 * Created by PhpStorm.
 * User: sau
 * Date: 21.03.18
 * Time: 11:09
 *
 * @package     Joomla.Administrator
 * @subpackage  com_asm
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\MVC\Controller\BaseController;

class ASMController extends BaseController {
	protected $default_view = 'pages';
}